export interface UserCart{
  id: number;
  userId: number;    
  firstName: string;
  lastName: string;
  bookId: number,
  title: string
  description: string
  author: string
}